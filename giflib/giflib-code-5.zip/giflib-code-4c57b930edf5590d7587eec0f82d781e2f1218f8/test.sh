cd tests
make
